package com.techm.Daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import com.techm.Models.Item;

public class ItemDao{
	
	
	private Connection connection;
	
	private String driverName="oracle.jdbc.driver.OracleDriver";
	private String ConnectionUrl="jdbc:oracle:thin:@localhost:1521:XE";
	private String userName="system";
	private String password="system";
	
	public ItemDao() {
		super();
	}
	
	public void createConnection(){
		
		try {
			Class.forName(driverName);
			this.connection=DriverManager.getConnection(ConnectionUrl, userName, password);
			System.out.println("---Connection Created---");
		} catch (SQLException e) {
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		System.out.println(connection);
		
	}
	
	public void closeConnection(){
		if(this.connection != null){
			try {
				this.connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public boolean addItem(Item item){
		boolean isAdded=false;
		createConnection();
		
		String query="insert into item values(?,?,?,?,?,?)";

		try {
			PreparedStatement ps=this.connection.prepareStatement(query);
			ps.clearParameters();
			
			ps.setString(1, item.getItemId());
			ps.setString(2, item.getItemName());
			ps.setInt(3,item.getPrice());
			ps.setString(4, item.getDateOfPrep());
			ps.setInt(5, item.getQuantityAvail());
			ps.setString(6, item.getTypeOfDelivery());
			
			if (ps.executeUpdate()==1) {
				System.out.println("---Item Added---");
				isAdded=true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		closeConnection();
		return isAdded;
	}
	
	public boolean checkItemPresence(Item item){
		boolean isValid=false;
		createConnection();
		String query="select * from item where itemId=? and itemName=?";
		
		try {
			PreparedStatement ps=this.connection.prepareStatement(query);
			ps.clearParameters();
			
			ps.setString(1, item.getItemId());
			ps.setString(2, item.getItemName());
			
			ResultSet resultSet=ps.executeQuery();
			if (resultSet.next()) {
				System.out.println("---Item Found---");
				isValid=true;
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		closeConnection();
		return isValid;	
	}
	
	public boolean updateItem(Item item){
		boolean isUpdated=false;
		
		
		String query="update item set itemName=?, price=?, dateofprep=?," +
						" quantityAvail=?, typeofdelivery=? where itemid=?";
		createConnection();
		
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.clearParameters();
			
			ps.setString(1, item.getItemName());
			ps.setInt(2, item.getPrice());
			ps.setString(3, item.getDateOfPrep());
			ps.setInt(4, item.getQuantityAvail());
			ps.setString(5, item.getTypeOfDelivery());
			ps.setString(6, item.getItemId());
			
			if (ps.executeUpdate()==1) {
				System.out.println("---Item Updated---");
				isUpdated=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		closeConnection();
		return isUpdated;
	}
	
	public ArrayList<Item> displayItems() {
		ArrayList<Item> arrayList=new ArrayList<Item>();
		String query="select * from item";
		createConnection();
		
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ResultSet resultSet=ps.executeQuery();
			while (resultSet.next()) {
				arrayList.add(new Item(resultSet.getString("itemid"), 
										resultSet.getString("itemName"), 
										resultSet.getInt("price"),
										resultSet.getString("dateofprep"),
										resultSet.getInt("quantityAvail"),
										resultSet.getString("typeofdelivery")));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Iterator<Item> itr=arrayList.iterator();
		while (itr.hasNext()) {
			Item item = (Item) itr.next();
			System.out.println(item);
		}
		closeConnection();
		return arrayList;
	}

	
	public boolean deleteItem(String itemId){
		boolean isDeleted=false;
		createConnection();
		
		String query="delete item where itemid=?";

		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.clearParameters();
			
			ps.setString(1, itemId);
			
			if (ps.executeUpdate()==1) {
				System.out.println("---Item Deleted---");
				isDeleted=true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		closeConnection();
		return isDeleted;
	}
}
