package com.techm.Daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.techm.Models.Orders;

public class OrdersDao {
	
	
	private Connection connection;
	private String driverName="oracle.jdbc.driver.OracleDriver";
	private String ConnectionUrl="jdbc:oracle:thin:@localhost:1521:XE";
	private String userName="system";
	private String password="system";
	
	public OrdersDao() {
		super();
	}
	

	public void createConnection(){
		
		try {
			Class.forName(driverName);
			this.connection=DriverManager.getConnection(ConnectionUrl, userName, password);
			System.out.println("---Connection Created---");
		} catch (SQLException e) {
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		System.out.println(connection);
		
	}
	
	public void closeConnection(){
		if(this.connection != null){
			try {
				this.connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public int getLastOrdId() {
		String query = "select ordId from orders";
		createConnection();
		int ordId=0;
		try {
			Statement st = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = st.executeQuery(query);
			rs.last();
			ordId=rs.getInt("ordId");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		closeConnection();
		return ordId;
	}
	
	public boolean placeOrder(Orders orders){
		createConnection();
		boolean isAdded=false;
		String query=" insert into orders values(?,?,?,?,?,?)";
		System.out.println(orders);
		String dateQuery="select to_char(sysdate,'dd')+5||'-'||to_char(sysdate,'mm')||'-'||to_char(sysdate,'yyyy') date1 from dual";
		
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.clearParameters();
			ps.setString(1, orders.getOrdId());
			ps.setString(2, orders.getUserId());
			ps.setInt(3, orders.getListId());
			ps.setInt(4, orders.getTotQuantity());
			ps.setInt(5, orders.getTotPrice());
			
			PreparedStatement datePs=connection.prepareStatement(dateQuery);
			ResultSet dateRs=datePs.executeQuery();
			if (dateRs.next()) {
				
				ps.setString(6, dateRs.getString("date1"));
				
				if (ps.executeUpdate()==1) {
					System.out.println("----Order Confirmed---");
					isAdded=true;
				}
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		closeConnection();
		return isAdded;
	}
	
	public int totPrice(int listId){
		createConnection();
		String query="select sum(price) totp from item where itemid in (select n.itemid from ordlist,TABLE(list) n where listid=?)";
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.clearParameters();
			ps.setInt(1, listId);
			
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				System.out.println("TOTAL PRICE = "+rs.getInt("totp"));
				System.out.println(new Date());
				return rs.getInt("totp");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		closeConnection();
		return 0;
	}
	
	public int totQuantity(int listId){
		createConnection();
		String query="select sum(n.quantityordered) totq from ordlist,TABLE(list) n where listid=?";
		
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.clearParameters();
			ps.setInt(1, listId);
			
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				System.out.println("TOTAL Quantity = "+rs.getInt("totq"));
				return rs.getInt("totq");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		closeConnection();
		return 0;
	}
	
	public String getCustomerName(int listId){
		createConnection();
		String query="select userId from ordlist where listId=?";
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.clearParameters();
			ps.setInt(1, listId);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				System.out.println("CustomerId:"+rs.getString("userId"));
				return rs.getString("userid");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		closeConnection();
		return null;
	}
//	select sum(n.quantityordered) from ordlist,TABLE(list) n where listid=1;
}
