package com.techm.Models;

public class Orders {
//	ordid varchar2(6) primary key, userid varchar2(10) references customer(userid), 
//	listid varchar2(5) references ordlist(listid), totquatity number(5,2), totprice number(7,2), timeofdelivery varchar2(10));
	private String ordId;
	private String userId;
	private int listId;
	private int totQuantity;
	private int totPrice;
	private String timeOfDelivery;
	
	public Orders() {
		super();
	}

	public Orders(String ordId, String userId, int listId, int totQuantity, int totPrice, String timeOfDelivery) {
		super();
		this.ordId = ordId;
		this.userId = userId;
		this.listId = listId;
		this.totQuantity = totQuantity;
		this.totPrice = totPrice;
		this.timeOfDelivery = timeOfDelivery;
	}

	public String getOrdId() {
		return ordId;
	}

	public void setOrdId(String ordId) {
		this.ordId = ordId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getListId() {
		return listId;
	}

	public void setListId(int listId) {
		this.listId = listId;
	}

	public int getTotQuantity() {
		return totQuantity;
	}

	public void setTotQuantity(int totQuantity) {
		this.totQuantity = totQuantity;
	}

	public int getTotPrice() {
		return totPrice;
	}

	public void setTotPrice(int totPrice) {
		this.totPrice = totPrice;
	}

	public String getTimeOfDelivery() {
		return timeOfDelivery;
	}

	public void setTimeOfDelivery(String timeOfDelivery) {
		this.timeOfDelivery = timeOfDelivery;
	}

	@Override
	public String toString() {
		return "Orders [ordId=" + ordId + ", userId=" + userId + ", listId=" + listId + ", totQuantity=" + totQuantity
				+ ", totPrice=" + totPrice + ", timeOfDelivery=" + timeOfDelivery + "]";
	}

}
