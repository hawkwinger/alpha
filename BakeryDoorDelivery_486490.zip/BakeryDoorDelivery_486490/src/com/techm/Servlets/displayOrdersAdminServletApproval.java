package com.techm.Servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.Daos.OrdListDao;
import com.techm.Daos.OrdersDao;
//import com.techm.Models.Customer;
import com.techm.Models.OrdList;
import com.techm.Models.Orders;


public class displayOrdersAdminServletApproval extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private OrdListDao ordListDao=null;
	private OrdersDao ordersDao=null;
	
	public void init(ServletConfig config) throws ServletException {
		ordListDao=new OrdListDao();
		ordersDao=new OrdersDao();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String options[]=request.getParameterValues("option");
		boolean isUpdated=false;
		
		HttpSession session=request.getSession();
		OrdList list=(OrdList)session.getAttribute("list");
		int listId=list.getListId();
		
//		Customer loggedInUser=(Customer)session.getAttribute("customer");
		
		isUpdated=ordListDao.setStatus(listId, options[0]);
		
		if (isUpdated==true) {
			
			System.out.println("Status Updated");
			boolean isPlaced=false;
			
			//-------ORDER OBJECT CREATION----
			int ordId=ordersDao.getLastOrdId()+1;
			int totPrice=ordersDao.totPrice(listId);
			int totQuantity=ordersDao.totQuantity(listId);
			String customerName=ordersDao.getCustomerName(listId);
			Orders orders=new Orders(new Integer(ordId).toString(),
									customerName, 
									listId, totQuantity, totPrice, "26/01/2017");
			System.out.println(orders);
			
			
			
			isPlaced=ordersDao.placeOrder(orders);
			if (isPlaced==true) {
				System.out.println("Order Placed Successfully");
				RequestDispatcher rd=request.getRequestDispatcher("/displayOrdersAdminServlet");
				rd.forward(request, response);
			}else {
				System.out.println("Order Not Placed");
				RequestDispatcher rd=request.getRequestDispatcher("/displayOrdersAdminServlet");
				rd.forward(request, response);
			}
			
		}else {
			System.out.println("Satus Not Updated");
			RequestDispatcher rd=request.getRequestDispatcher("/displayOrdersAdminServlet");
			rd.forward(request, response);
		}
		
	}

}
