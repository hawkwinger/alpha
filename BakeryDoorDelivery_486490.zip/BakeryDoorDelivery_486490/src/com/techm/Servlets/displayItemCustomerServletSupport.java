package com.techm.Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.Daos.OrdListDao;
import com.techm.Models.Customer;

public class displayItemCustomerServletSupport extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private OrdListDao ordListDao;
	
	public void init(ServletConfig config) throws ServletException {
		ordListDao=new OrdListDao();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		boolean isAdded=false;
		
		int listId=ordListDao.getLastListId()+1;
		
		HttpSession session=request.getSession();
		Customer customer=(Customer)session.getAttribute("customer");
		
		HashMap<String, Integer> ordList=new HashMap<String, Integer>();
		
		String choices[]=request.getParameterValues("choice");
		
		for (int i = 0; i < choices.length; i++) {
			ordList.put(choices[i], Integer.parseInt(request.getParameter("quantityOrdered"+choices[i])) );
		}
		
		Iterator<Map.Entry<String, Integer>> itr=ordList.entrySet().iterator();
		while (itr.hasNext()) {
			Map.Entry<String, Integer> entry = (Map.Entry<String, Integer>) itr.next();
			System.out.println("CHECKBOXID="+entry.getKey()+" QUANTITY="+entry.getValue());
		}
		
		isAdded=ordListDao.addOrder(listId,customer.getUserId(),"WAITING", ordList);
		
		if (isAdded==true) {
			System.out.println("---Order Placed Wait For Admin Approval---");
			out.println("<body>alert(\"Order Placed Successfully\");</body>");
			RequestDispatcher rd=request.getRequestDispatcher("/menuForCustomerServlet");
			rd.forward(request, response);
			
		}else {
			System.out.println("---Order Cannot Be Placed---");
			RequestDispatcher rd=request.getRequestDispatcher("/menuForCustomerServlet");
			rd.forward(request, response);
		}
	
	}

}
