package com.techm.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.Daos.AdminDao;
import com.techm.Daos.CustomerDao;
import com.techm.Models.Admin;
import com.techm.Models.Customer;

public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CustomerDao customerDao=null;
	private AdminDao adminDao=null;
	
	
	public void init(ServletConfig config) throws ServletException {
		customerDao=new CustomerDao();
		adminDao=new AdminDao();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			boolean isValid=false;
			
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
			
			HttpSession session=request.getSession();
			
			String userId=request.getParameter("userId");
			String password=request.getParameter("password");
			
			if(userId.isEmpty() || password.isEmpty()){
				
				out.println("<body bgcolor=\"lightblue\">"
						+"<center>" 
						+"<h1>BAKERY DOOR DELIVERY</h1>"
						+ "<h3>LOGIN UNSUCCESSFULLY !!</h3>"
						+"<h3>FIELDS CANT BE LEFT EMPTY</h3>"
						+ "<a href='login.html'> Re-Login </a><br>"
						+ "<a href='homepage.html'>Go Home </a>"
						+ "</center>"
						+ "</body>");
				
			}else{
					Customer customer=new Customer();
					customer.setUserId(userId);
					customer.setPassword(password);
					
					isValid=customerDao.checkCustomerPresence(customer);
					
					if(isValid==true){ //if customer
						
						System.out.println("---Customer Logged in---");
						session.setAttribute("customer", customer);
						
						RequestDispatcher requestDispatcherCustomer=request.getRequestDispatcher("/menuForCustomerServlet");
						requestDispatcherCustomer.forward(request, response);
						
					}else {
						
						isValid=adminDao.checkCustomerPresence(new Admin(userId, password));
						if(isValid==true){ //if Admin
							
							System.out.println("--Admin logged in---");
							session.setAttribute("customer", customer);
							
							RequestDispatcher requestDispatcherAdmin=request.getRequestDispatcher("/menuForAdminServlet");
							requestDispatcherAdmin.forward(request, response);
							
						}else{
							response.sendRedirect
							("http://localhost:7001/BakeryDoorDelivery_486490/invaliduser.html");
						}
						
					}
			}
	}

}
