package com.techm.Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.Daos.OrdListDao;
import com.techm.Models.Customer;
import com.techm.Models.OrdList;


public class displayOrdersAdminServletSupport extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private OrdListDao ordListDao;
	public void init(ServletConfig config) throws ServletException {
		ordListDao=new OrdListDao();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String options[]=request.getParameterValues("option");
		ArrayList<OrdList> ordList=null;
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		HttpSession session=request.getSession();
		Customer customer=(Customer)session.getAttribute("customer");
		
		for (int i = 0; i < 50; i++) {
			if (options[0].compareTo(new Integer(i).toString())==0) {
				ordList=ordListDao.getOrderList(i);
				break;
			}
		}
		
		session.setAttribute("list", ordList.get(0));
		
		out.println("<body bgcolor=\"cyan\"><center>"
				+"<h1>BAKERY DOOR DELIVERY</h1>"
				+"<MARQUEE>WELCOME TO BIHAR BAKERY</MARQUEE>" 
				+"<h3> HELLO "+customer.getUserId()+" (ADMIN) </h3>"
				+"<hr>"
				+"<h3>LIST ID : "+ordList.get(0).getListId()+"   OF   USER ID : "+ordList.get(0).getUserId()+"</h3>"
				+"<hr>"
				+"<form method=\"post\" action=\"displayOrdersAdminServletApproval\">"
				+"<table border=\"1\">"
				+"<tr><td>ITEM ID</td><td>QUANTITY ORDERED</td></tr>");
				
		for (int i = 0; i < ordList.size(); i++) {
			out.println("<tr><td>"+ordList.get(i).getItemId()+"</td><td>"+ordList.get(i).getQuantityOrdered()+"</td></tr>");
		}
		
		out.println("</table>"
				+"<input type=\"radio\" name=\"option\" value=\"APPROVED\">APPROVE</input><br><br>"
				+"<input type=\"radio\" name=\"option\" value=\"REJECTED\">REJECT</input><br><br>"
				+"<input type=\"submit\" value=\"submit\">"
				+"</form>"
				+"</center></body>");
		
		
	}

}
