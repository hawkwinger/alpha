package com.techm.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.Models.Customer;

public class menuForCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   public menuForCustomerServlet() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession session=request.getSession();
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		Customer customer=(Customer) session.getAttribute("customer");
		
		out.println("<body bgcolor=\"Cyan\">"
					+"<center>"
					+"<h1>BAKERY DOOR DELIVERY</h1>"
					+"<MARQUEE>WELCOME TO BIHAR BAKERY</MARQUEE>" 
					+"<h3> HELLO "+customer.getUserId()+" (CUSTOMER) </h3>"
					+"<table border=\"1\">"
					+"<tr><td> <a href=displayItemCustomerServlet> DISPLAY ITEMS TO ORDER</a></td><td></td></tr>"
					+"<tr><td> <a href=deleteItemCustomerServlet> DELETE ITEM FROM MY ORDER</a></td><td></td></tr>"
					+"<tr><td> <a href=displayOrderCustomerServlet> DISPLAY MY ORDERS</a></td><td></td></tr>"
					+"<tr><td> <a href=logoutServlet> LOG OUT </a></td><td></td></tr>"
					+"</table></center></body>");
	}

}
