 package com.techm.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techm.Daos.CustomerDao;
import com.techm.Models.Customer;

public class registerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CustomerDao customerDao=null;
	
	public void init(ServletConfig config) throws ServletException {
		this.customerDao=new CustomerDao();
		}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException, IOException {
		doPost(request, response);		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException, IOException {
		
		boolean isAdded=false;
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String userId=request.getParameter("userId");
		String password1=request.getParameter("password1");
		String password2=request.getParameter("password2");
		String custName=request.getParameter("custName");
		String contactNo=request.getParameter("contactNo");
		String emailId=request.getParameter("emailId");
	
		String doorno=request.getParameter("doorno");
		String street=request.getParameter("street");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String zip=request.getParameter("zip");
		 
		if(!password1.isEmpty() && !password2.isEmpty() && password1.compareTo(password2)==0){
			
			if(!userId.isEmpty() && !custName.isEmpty() && !contactNo.isEmpty() && !emailId.isEmpty() 
					&& !doorno.isEmpty() && !street.isEmpty() && !city.isEmpty() && !state.isEmpty() && !zip.isEmpty()){
				
			isAdded=customerDao.addCustomer(new Customer(userId, password1, custName, contactNo, 
													emailId, doorno, street, city, state, zip));
			
			if(isAdded == true){
				out.println("<body bgcolor=\"lightblue\">"
						+"<center><h1>BAKERY DOOR DELIVERY</h1>"
						+ "<h3>WELCOME "+request.getParameter("userId")+"</h3>"
						+ "<h3>YOU HAVE REGISTERED SUCCESSFULLY !!</h3>"
						+ "<a href='login.html'>CLICK HERE TO LOGIN</a><br>"
						+ "<a href='homepage.html'>CLICK HERE TO HOME</a>"
						+ "</center>"
						+ "</body>");
			}else{
				out.println("<body bgcolor=\"lightblue\">"
						+"<center><h1>BAKERY DOOR DELIVERY</h1>"
						+ "<h3>REGISTRATION UNSUCCESSFULLY !!</h3>"
						+ "<h3>INCORRECT FIELDS ENTRY</h3>"
						+ "<a href='register.html'>CLICK HERE TO RE-REGISTER</a><br>"
						+ "<a href='homepage.html'>CLICK HERE TO HOME</a>"
						+ "</center>"
						+ "</body>");
			}
			
			}else{

				out.println("<body bgcolor=\"lightblue\">"
						+"<center>" 
						+"<h1>BAKERY DOOR DELIVERY</h1>"
						+ "<h3>REGISTRATION UNSUCCESSFULLY !!</h3>"
						+"<h3>FIELDS CANT BE LEFT EMPTY</h3>"
						+ "<a href='register.html'>CLICK HERE TO RE-REGISTER</a><br>"
						+ "<a href='homepage.html'>CLICK HERE TO HOME</a>"
						+ "</center>"
						+ "</body>");
			}
		}else{
			out.println("<body bgcolor=\"lightblue\">"
					+"<center><h1>BAKERY DOOR DELIVERY</h1>"
					+ "<h3>REGISTRATION UNSUCCESSFULLY !!</h3>"
					+"<h3>INCORRECT PASSWORD</h3>"
					+ "<a href='register.html'>CLICK HERE TO RE-REGISTER</a><br>"
					+ "<a href='homepage.html'>CLICK HERE TO HOME</a>"
					+ "</center>"
					+ "</body>");
		}		
	}
	
	@Override
	public void destroy() {
		this.customerDao=null;
	}

}
